﻿class Offboard {
[string]$Office365LoginID
[System.Management.Automation.PSCredential]$Office365Credentials
[string]$UserEmail
[string]$InternalAutoReplyMessage
[string]$ExternalAutoReplyMessage
[System.Object]$Session

[bool]GetOffice365Credentials()
{
$this.Office365Credentials = Get-Credential -Message 'Enter your Office365 Credentials'
return $true
}

[bool]LoginExchangeOnline()
{
$this.Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $this.Office365Credentials -Authentication Basic -AllowRedirection
Import-PSSession $this.Session  -DisableNameChecking
return $true
}

EnableAutoReply()
{
Set-MailboxAutoReplyConfiguration -Identity $this.UserEmail -AutoReplyState Enabled -InternalMessage $this.InternalAutoReplyMessage -ExternalMessage $this.ExternalAutoReplyMessage
}

Wizard()
{
Write-Host 'We need the email address of the user' -ForegroundColor Green
$this.UserEmail = Read-Host -Prompt 'Enter Email address' 
Write-Host 'Please enter your office365 credentials'
$this.GetOffice365Credentials()
Write-Host 'Enter your internal message' -ForegroundColor Green
$this.InternalAutoReplyMessage =  Read-Host -Prompt 'Enter Message'
Write-Host 'Enter your external message' -ForegroundColor Green
$this.ExternalAutoReplyMessage = Read-Host -Prompt 'Enter Message'
$this.offboarding.LoginExchangeOnline()
$this.offboarding.EnableAutoReply()

}

}


