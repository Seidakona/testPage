﻿$CurrentPath = $PSScriptRoot

#Import Functions
Import-module  "$CurrentPath\Functions\Functions.psm1" -Force -Verbose

#Import Classes
$scriptBody = @"
using module "$CurrentPath\Classes\Deactivate_Class.psm1"
"@
$script = [ScriptBlock]::Create($scriptBody)
. $script



Write-Host 'Version 1.0'
Write-Host
Write-Host 'Hello What would you like to do today?'
Write-Host $(Menu-Options)
$MenuChoice = Read-Host

switch($MenuChoice)
{
    1{Start-OffboardUser}
    2{AddTwoNumbers -num1 $number1 -num2 $number2}
    
    else {
        Write-host "You selected an incorrect number"
    }

}

