function Menu-Options {
    $menuOption = @"
1) Deactivate User
2) Add Two Numbers
3) Multiply Two Numbers
"@
    return $menuOption
}

function Start-OffboardUser {
    param (
        $userEmail
    )
    [Offboard]$offboard = [offboard]::new()
    $offboard.Wizard()
}

function AddTwoNumbers {
    
    $num1 = Read-Host -Prompt 'Enter a value'
    $num2 = Read-Host -Prompt 'Enter a second value to add to the first'
    return $($num1 + $num2)
}

function MultiplyTwoNumbers {
    
    $num1 = Read-Host -Prompt 'Enter a value'
    $num2 = Read-Host -Prompt 'Enter a second value to add to the first'
    return $($num1 * $num2)
}
