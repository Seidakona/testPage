﻿$CurrentPath = $PSScriptRoot

#Import Functions
Import-module  "$CurrentPath\Functions.psm1" -Force -Verbose

#Import Classes
$scriptBody = @"
using module "$CurrentPath\Deactivate_Class.psm1"
"@
$script = [ScriptBlock]::Create($scriptBody)
. $script



Write-Host 'Version 1.0.0'
Write-Host
Write-Host 'Hello What would you like to do today?'
Write-Host $(Menu-Options)
$MenuChoice = Read-Host

switch($MenuChoice)
{
    1{Start-OffboardUser}
    2{AddTwoNumbers }
    2{MultiplyTwoNumbers}
    
    else {
        Write-host "You selected an incorrect number"
    }

}

