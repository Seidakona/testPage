function Menu-Options {
    $menuOption = @"
1) Deactivate User
2) Update
"@
    return $menuOption
}

function Start-OffboardUser {
    param (
        $userEmail
    )
    [Offboard]$offboard = [offboard]::new()
    $offboard.Wizard()
}
